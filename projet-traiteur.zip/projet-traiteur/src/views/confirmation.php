<?php include 'src/views/layout/header.php'; ?>

<div class="confirmation-wrapper">
    <h1>Merci pour votre commande !</h1>

    <p>Votre commande a bien été enregistrée.</p>

    <a href="index.php" class="home-btn">Retour à l'accueil</a>
</div>

<?php include 'src/views/layout/footer.php'; ?>
