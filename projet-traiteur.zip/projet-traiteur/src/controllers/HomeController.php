<?php

class HomeController {
    public function index() {
        require __DIR__ . '/../views/home/home.php';
    }
}
