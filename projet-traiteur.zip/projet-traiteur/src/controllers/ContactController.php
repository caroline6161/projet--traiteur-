<?php

class ContactController
{
    public function index()
    {
        include 'src/views/contact/contact.php';
    }
}
